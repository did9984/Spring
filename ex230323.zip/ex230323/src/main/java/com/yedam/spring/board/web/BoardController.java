package com.yedam.spring.board.web;

import org.springframework.stereotype.Controller;


@Controller
public class BoardController {
	
	// 전체조회
	
	// 단건조회
	
	// 등록
	
	// 수정
	
	// 삭제
}
