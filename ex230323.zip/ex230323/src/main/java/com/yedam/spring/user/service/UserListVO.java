package com.yedam.spring.user.service;

import java.util.List;

import lombok.Data;

@Data
public class UserListVO {
	private List<UserVO> list;
}

